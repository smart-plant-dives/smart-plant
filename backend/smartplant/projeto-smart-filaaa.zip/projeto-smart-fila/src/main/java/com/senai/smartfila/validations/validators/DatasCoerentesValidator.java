package com.senai.smartfila.validations.validators;

import java.time.LocalDate;

import com.senai.smartfila.entities.Aluno;
import com.senai.smartfila.validations.annotations.DatasCoerentes;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DatasCoerentesValidator implements ConstraintValidator<DatasCoerentes, Aluno> {
	
	@Override
	public boolean isValid(Aluno aluno, ConstraintValidatorContext context) {
		if(aluno == null) {
			return true;
		}
		
		LocalDate dataNascimento = aluno.getDataNascimento();
		if(aluno.getDocumentos() == null) {
			return true;
		}
		
		LocalDate dataEmissao = aluno.getDocumentos().getDataEmissao();
		
		if(dataNascimento == null || dataEmissao == null) {
			return true;
		}	
		//            valida se uma data é posterior ou anterior a que esta postando
		boolean valido = !dataEmissao.isBefore(dataNascimento);
		
		if(!valido) {
			context.disableDefaultConstraintViolation();
			
			context.buildConstraintViolationWithTemplate(
					"A data de emissão não pode ser anterior à data da nascimento."
					)
			.addPropertyNode("documento")
			.addPropertyNode("dataEmissao")
			.addConstraintViolation();
		}
		return valido;
	} 
}









