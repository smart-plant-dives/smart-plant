package com.senai.smartfila.validations.validators;

import com.senai.smartfila.validations.annotations.RAValido;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class RAValidoValidator implements ConstraintValidator<RAValido, String>{
	
	@Override
	public boolean isValid(String valor, ConstraintValidatorContext context) {
		
		if (valor == null) {
			return true;
		}
		
		String regex = "^RA-\\d{4}-\\d{4}$";
		  return valor.matches(regex);
	}
}
