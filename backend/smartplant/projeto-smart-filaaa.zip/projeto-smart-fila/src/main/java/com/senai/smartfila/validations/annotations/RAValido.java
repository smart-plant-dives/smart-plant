package com.senai.smartfila.validations.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.senai.smartfila.validations.validators.RAValidoValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Documented
@Constraint(validatedBy = RAValidoValidator.class)
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RAValido {
	
	String message() default "RA inválido.";
	
	Class<?>[] groups() default {};
	
	Class<? extends Payload>[] payload() default {};
}