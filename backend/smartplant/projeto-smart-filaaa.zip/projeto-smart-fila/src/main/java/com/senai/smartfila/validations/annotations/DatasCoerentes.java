package com.senai.smartfila.validations.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.senai.smartfila.validations.validators.DatasCoerentesValidator;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

@Documented
@Constraint(validatedBy = DatasCoerentesValidator.class)
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface DatasCoerentes {
	
	String message() default "As datas são incoerentes.";
	
	Class<?>[] groups() default{};
	Class<? extends Payload>[] payload() default{};
}